﻿using UnityEngine;
using System.Collections;

public class WindowInteraction : MonoBehaviour {

    public float Rotation = 90;
    public int RepeatAmount = 12;


	void Start ()
    {
	    
	}
	
	// Update is called once per frame
	void Update ()
    {
	    
	}

    void WindowAnimation()
    {

    }
}
