﻿using UnityEngine;
using System.Collections;

public class ResidentsFearBar : MonoBehaviour {
    public GameObject fearBar;
}
