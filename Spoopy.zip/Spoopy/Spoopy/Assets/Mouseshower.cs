﻿using UnityEngine;
using System.Collections;

public class Mouseshower : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Cursor.visible = true;
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
